# Personal Portfolio Website

## Overview

This is a personal portfolio website for Lavudi Suresh, a Business Development Manager with 4+ years of experience in healthcare, technology, and service industries. The application is a full-stack web application built with React frontend and Express.js backend, featuring a modern, responsive design that showcases professional experience, skills, and contact information.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom design tokens and shadcn/ui component library for consistent, modern UI components
- **Build Tool**: Vite for fast development and optimized production builds
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Extensive use of Radix UI primitives through shadcn/ui for accessibility and consistent behavior
- **Animations**: Framer Motion for smooth animations and transitions
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Framework**: Express.js with TypeScript for server-side logic
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage**: Dual storage implementation with in-memory storage for development and PostgreSQL for production
- **API Design**: RESTful API structure with proper error handling middleware
- **Session Management**: Express sessions with PostgreSQL session store for user authentication

### Data Storage Solutions
- **Database**: PostgreSQL as the primary database with Neon Database serverless hosting
- **ORM**: Drizzle ORM chosen for type safety, performance, and excellent TypeScript integration
- **Migration**: Drizzle Kit for database schema migrations and management
- **Schema**: Centralized schema definition in shared directory for consistency between frontend and backend

### Development Architecture
- **Monorepo Structure**: Organized with separate client, server, and shared directories
- **TypeScript Configuration**: Unified TypeScript configuration with path mapping for clean imports
- **Development Server**: Vite dev server with Express backend proxy for seamless development experience
- **Hot Module Replacement**: Full HMR support for both frontend and backend development

### UI/UX Design Decisions
- **Design System**: Custom design tokens extending Tailwind CSS with semantic color variables
- **Component Architecture**: Modular component structure with clear separation of concerns
- **Responsive Design**: Mobile-first approach with breakpoint-specific layouts
- **Accessibility**: Built-in accessibility features through Radix UI primitives
- **Typography**: Custom font stack with Inter, Poppins, and Playfair Display for visual hierarchy

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting for production deployment
- **Database URL**: Environment-based configuration for flexible deployment environments

### UI Component Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives for building design system components
- **shadcn/ui**: Pre-built component library built on top of Radix UI with Tailwind CSS styling
- **Lucide React**: Modern icon library for consistent iconography throughout the application

### Development Tools
- **Replit Integration**: Specialized Vite plugins for Replit development environment including error overlay and dev banner
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer for cross-browser compatibility

### Build and Deployment
- **esbuild**: Fast JavaScript bundler for server-side code compilation
- **Vite**: Modern build tool for frontend with optimized production builds and development experience

### Form and Data Handling
- **Zod**: TypeScript-first schema validation library for form validation and API data validation
- **React Hook Form**: Performant form library with built-in validation support
- **date-fns**: Lightweight date manipulation library for handling date formatting and calculations

### Styling and Animation
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **Framer Motion**: Production-ready motion library for React animations and gestures
- **class-variance-authority**: Utility for creating variant-based component APIs with TypeScript support