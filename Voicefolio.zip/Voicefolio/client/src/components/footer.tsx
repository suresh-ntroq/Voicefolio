import { motion } from "framer-motion";
import { Mail, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary dark:bg-gray-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="font-serif text-3xl font-bold text-foreground dark:text-white mb-4">Lavudi Suresh</div>
          <p className="text-muted-foreground dark:text-white/80 mb-6">Business Development Professional</p>
          <div className="flex justify-center space-x-6">
            <a
              href="mailto:vizianagaram.suresh@gmail.com"
              className="text-muted-foreground dark:text-white/80 hover:text-primary dark:hover:text-white transition-colors"
              data-testid="link-email-footer"
            >
              <Mail className="w-6 h-6" />
            </a>
            <a
              href="tel:+919121156984"
              className="text-muted-foreground dark:text-white/80 hover:text-primary dark:hover:text-white transition-colors"
              data-testid="link-phone-footer"
            >
              <Phone className="w-6 h-6" />
            </a>
          </div>
          <div className="mt-8 pt-8 border-t border-border dark:border-white/20 text-muted-foreground dark:text-white/80 text-sm">
            <p>&copy; 2024 Lavudi Suresh. All rights reserved.</p>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
