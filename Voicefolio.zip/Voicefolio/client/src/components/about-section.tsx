import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-background dark:bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-4xl font-bold text-foreground dark:text-white mb-8">About Me</h2>
            <div className="space-y-6 text-muted-foreground dark:text-white/80 text-lg leading-relaxed">
              <p>
                I am a dedicated Business Development Manager with over 4 years of experience in driving 
                growth across healthcare, technology, and service sectors. My career journey has taken me 
                through diverse industries, from genetic health testing to hair restoration services and 
                healthcare solutions.
              </p>
              <p>
                My approach combines analytical thinking with strong interpersonal skills to identify 
                opportunities, build relationships, and deliver results. I specialize in customer acquisition, 
                conversion optimization, and maintaining long-term client relationships through strategic CRM management.
              </p>
              <p>
                Currently seeking opportunities to leverage my experience in a challenging environment that 
                offers professional growth and the chance to make a significant impact on business outcomes.
              </p>
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="mt-8 grid grid-cols-2 gap-6"
            >
              <div className="bg-card dark:bg-white/10 p-6 rounded-lg border dark:border-white/20">
                <div className="text-3xl font-bold text-primary mb-2" data-testid="text-years-experience">4+</div>
                <div className="text-muted-foreground dark:text-white/60">Years Experience</div>
              </div>
              <div className="bg-card dark:bg-white/10 p-6 rounded-lg border dark:border-white/20">
                <div className="text-3xl font-bold text-primary mb-2" data-testid="text-companies-worked">5</div>
                <div className="text-muted-foreground dark:text-white/60">Companies Worked</div>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="bg-card dark:bg-white/10 p-8 rounded-xl border dark:border-white/20">
              <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-4">Professional Summary</h3>
              <ul className="space-y-3 text-muted-foreground dark:text-white/80">
                <li className="flex items-start">
                  <CheckCircle className="text-primary mt-1 mr-3 w-5 h-5 flex-shrink-0" />
                  B.Tech in Mechanical Engineering (2012-2016)
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-primary mt-1 mr-3 w-5 h-5 flex-shrink-0" />
                  Expertise in customer acquisition and relationship management
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-primary mt-1 mr-3 w-5 h-5 flex-shrink-0" />
                  Strong background in healthcare and technology sectors
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-primary mt-1 mr-3 w-5 h-5 flex-shrink-0" />
                  Multilingual: Telugu, Hindi, and English
                </li>
              </ul>
            </div>
            
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 dark:from-primary/20 dark:to-accent/20 p-8 rounded-xl border dark:border-white/20">
              <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-4">Career Objective</h3>
              <p className="text-muted-foreground dark:text-white/80 leading-relaxed">
                To obtain a long-term career with an organization that has a strong background and 
                provides good opportunities for enhancement of professional and individual growth.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
