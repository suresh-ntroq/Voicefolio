import { motion } from "framer-motion";
import { Laptop, Users, Code, Image, Brain, RotateCcw, GraduationCap, MessageCircle, Languages } from "lucide-react";

interface Skill {
  name: string;
  level: number;
}

interface TechnicalSkill {
  icon: any;
  name: string;
  description: string;
}

interface PersonalTrait {
  icon: any;
  name: string;
  description: string;
}

const businessSkills: Skill[] = [
  { name: "Customer Acquisition", level: 95 },
  { name: "Relationship Management", level: 90 },
  { name: "Sales Conversion", level: 85 },
  { name: "Communication Skills", level: 92 }
];

const technicalSkills: TechnicalSkill[] = [
  { icon: Laptop, name: "MS Office Suite", description: "Word, Excel, PowerPoint" },
  { icon: Users, name: "CRM Systems", description: "Customer Management" },
  { icon: Code, name: "HTML & CSS", description: "Basic Web Development" },
  { icon: Image, name: "Photoshop", description: "Design & Editing" }
];

const personalTraits: PersonalTrait[] = [
  { icon: Brain, name: "Smart Worker", description: "Skilled and intelligent approach to problem-solving" },
  { icon: RotateCcw, name: "Adaptable", description: "Flexible with changing work environments" },
  { icon: GraduationCap, name: "Eager Learner", description: "Always willing to learn and grow professionally" },
  { icon: MessageCircle, name: "Communicator", description: "Excellent verbal and written communication" }
];

const languages = [
  { name: "Telugu", level: "Native" },
  { name: "Hindi", level: "Fluent" },
  { name: "English", level: "Professional" }
];

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-background dark:bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl font-bold text-foreground dark:text-white mb-4">Skills & Expertise</h2>
          <p className="text-xl text-muted-foreground dark:text-white/80 max-w-3xl mx-auto">
            A comprehensive skill set covering technical abilities, business acumen, and personal strengths
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Technical Skills */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-8">Technical Skills</h3>
            <div className="grid grid-cols-2 gap-4">
              {technicalSkills.map((skill, index) => {
                const IconComponent = skill.icon;
                return (
                  <div
                    key={index}
                    className="skill-item bg-card dark:bg-white/10 p-6 rounded-lg border dark:border-white/20 text-center hover:bg-primary hover:text-primary-foreground dark:hover:bg-primary dark:hover:text-white transition-all cursor-pointer"
                    data-testid={`skill-technical-${index}`}
                  >
                    <IconComponent className="w-8 h-8 mx-auto mb-3 text-primary" />
                    <div className="font-semibold">{skill.name}</div>
                    <div className="text-sm text-muted-foreground mt-1">{skill.description}</div>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Business Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-8">Business Skills</h3>
            <div className="space-y-4">
              {businessSkills.map((skill, index) => (
                <div key={index} className="bg-card dark:bg-white/10 p-6 rounded-lg border dark:border-white/20" data-testid={`skill-business-${index}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-foreground dark:text-white">{skill.name}</span>
                    <span className="text-primary font-semibold" data-testid={`skill-level-${index}`}>{skill.level}%</span>
                  </div>
                  <div className="w-full bg-secondary dark:bg-gray-700 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="bg-primary h-2 rounded-full"
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Personal Traits */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-8 text-center">Personal Traits</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {personalTraits.map((trait, index) => {
              const IconComponent = trait.icon;
              return (
                <div key={index} className="bg-card dark:bg-white/10 p-6 rounded-lg border dark:border-white/20 text-center" data-testid={`trait-${index}`}>
                  <IconComponent className="w-10 h-10 text-primary mx-auto mb-4" />
                  <h4 className="font-semibold text-foreground dark:text-white mb-2">{trait.name}</h4>
                  <p className="text-muted-foreground dark:text-white/80 text-sm">{trait.description}</p>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Languages */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-r from-primary/10 to-accent/10 dark:from-primary/20 dark:to-accent/20 p-8 rounded-xl border dark:border-white/20"
        >
          <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-6 text-center">Languages</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {languages.map((language, index) => (
              <div key={index} className="text-center" data-testid={`language-${index}`}>
                <Languages className="w-8 h-8 text-primary mx-auto mb-3" />
                <div className="font-semibold text-foreground dark:text-white">{language.name}</div>
                <div className="text-muted-foreground dark:text-white/60 text-sm">{language.level}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
