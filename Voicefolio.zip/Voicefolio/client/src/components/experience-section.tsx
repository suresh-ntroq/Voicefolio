import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

interface ExperienceItem {
  period: string;
  duration: string;
  title: string;
  company: string;
  department: string;
  responsibilities: string[];
}

const experiences: ExperienceItem[] = [
  {
    period: "Oct 2023 - May 2024",
    duration: "8 months",
    title: "Inside Sales Associate",
    company: "Mapmygenome Pvt. Ltd.",
    department: "Airport Inside Sales",
    responsibilities: [
      "Connected with airport visitors and introduced genetic health testing services",
      "Explained benefits and features of health tests to drive purchase decisions",
      "Managed customer data in CRM and maintained relationships through regular follow-ups"
    ]
  },
  {
    period: "Jan 2023 - Sep 2023",
    duration: "9 months",
    title: "Counsellor",
    company: "Eugenix Hair Sciences",
    department: "Hair Restoration Services",
    responsibilities: [
      "Assessed patient conditions and graded hair loss issues in consultation with doctors",
      "Presented treatment packages and convinced patients through detailed benefit explanations",
      "Managed patient relationships and guided them through treatment processes"
    ]
  },
  {
    period: "Apr 2021 - Jan 2023",
    duration: "1 year 10 months",
    title: "Business Development Manager",
    company: "Pristyn Care",
    department: "Proctology Department",
    responsibilities: [
      "Diagnosed patient conditions through symptom analysis and medical consultations",
      "Convinced patients to take consultations and guided them through treatment decisions",
      "Presented surgical packages and managed patient conversion process"
    ]
  },
  {
    period: "Oct 2020 - Apr 2021",
    duration: "7 months",
    title: "Driver Value Propagator",
    company: "Teleperformance Indore",
    department: "Uber Project",
    responsibilities: [
      "Conducted outbound calls to explain Uber driver benefits and platform features",
      "Converted prospects into driver partners through strategic presentations",
      "Scheduled appointments at boarding offices for partnership onboarding"
    ]
  },
  {
    period: "Aug 2019 - Oct 2019",
    duration: "3 months",
    title: "Customer Service Representative",
    company: "Teleperformance Pvt. Ltd.",
    department: "Uber Project",
    responsibilities: [
      "Identified and resolved driver queries using internal support tools",
      "Educated drivers on platform functionality and payment processes",
      "Provided comprehensive customer support and troubleshooting assistance"
    ]
  }
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-secondary dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl font-bold text-foreground dark:text-white mb-4">Professional Experience</h2>
          <p className="text-xl text-muted-foreground dark:text-white/80 max-w-3xl mx-auto">
            A comprehensive overview of my career journey across various industries and roles
          </p>
        </motion.div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="experience-card bg-card dark:bg-white/10 p-8 rounded-xl border dark:border-white/20"
              data-testid={`experience-card-${index}`}
            >
              <div className="grid lg:grid-cols-4 gap-6">
                <div className="lg:col-span-1">
                  <div className="text-primary font-semibold text-sm uppercase tracking-wide" data-testid={`text-period-${index}`}>
                    {exp.period}
                  </div>
                  <div className="text-muted-foreground dark:text-white/60 text-sm mt-1" data-testid={`text-duration-${index}`}>
                    {exp.duration}
                  </div>
                </div>
                <div className="lg:col-span-3">
                  <h3 className="font-display text-2xl font-bold text-foreground dark:text-white mb-2" data-testid={`text-title-${index}`}>
                    {exp.title}
                  </h3>
                  <div className="text-primary font-semibold mb-4" data-testid={`text-company-${index}`}>
                    {exp.company} • {exp.department}
                  </div>
                  <ul className="space-y-2 text-muted-foreground dark:text-white/80">
                    {exp.responsibilities.map((responsibility, respIndex) => (
                      <li key={respIndex} className="flex items-start" data-testid={`text-responsibility-${index}-${respIndex}`}>
                        <ArrowRight className="text-primary mt-1 mr-3 w-4 h-4 flex-shrink-0" />
                        {responsibility}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
