import { motion } from "framer-motion";
import professionalPhoto from "@assets/IMG-20211112-WA0038-01_1757815222596.jpeg";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="hero-gradient min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <h1 className="font-serif text-5xl lg:text-7xl font-bold text-white mb-6">
              Hi. I'm <span className="text-accent-foreground">Suresh.</span>
              <br />
              I Drive Business Growth.
            </h1>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              Experienced Business Development Manager with a proven track record in healthcare, 
              technology, and service industries. Specializing in customer acquisition, 
              relationship management, and revenue growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={() => scrollToSection("experience")}
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 rounded-lg font-semibold transition-all hover:scale-105"
                data-testid="button-view-experience"
              >
                View Experience
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-4 rounded-lg font-semibold transition-all"
                data-testid="button-get-in-touch"
              >
                Get In Touch
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-center lg:justify-end"
          >
            {/* Professional headshot */}
            <div className="w-80 h-80 rounded-full overflow-hidden border-4 border-white/20 shadow-2xl">
              <img 
                src={professionalPhoto} 
                alt="Lavudi Suresh - Business Development Professional" 
                className="w-full h-full object-cover"
                data-testid="img-professional-photo"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
